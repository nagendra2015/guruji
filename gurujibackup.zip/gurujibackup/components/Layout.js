import Navbarmenu from "./Navbarmenu";
import { motion } from "framer-motion";
import News from "./News";
import Basiccourse from "./Basiccourse";

const Layout = ({ mainTitle, footer, children }) => (
  <div>
    <Navbarmenu />

    {/* <!-- About Start --> */}
    <div className="container-xxl">
      <div className="container">
        <div className="pageColor rounded">
          <div className="row">
            {/* <!--content page Start --> */}
            <div className="col-lg-9">{children}</div>
            {/* <!-- page end --> */}
            {/* <!-- page right side Start --> */}

            <div className="col-lg-3 rightsidebar">
              <div className="pt-1">
                <div className="fs-5 justifytext">
                  <News></News>
                </div>


                <div className="fs-5 justifytext">
                  <Basiccourse></Basiccourse>
                </div>





                <motion.div
                  className="card  titlestrip"
                  initial={{ x: 300, scale: 0.5 }}
                  animate={{ x: 0, scale: 1 }}
                  transition={{ duration: 2 }}
                >
                  <div className="card-header text-white">
                    <h3> Youtube Video</h3>
                  </div>
                  <div className="fs-5 justifytext">
                    <div className="video-responsive">
                      <iframe
                        src={
                          "https://www.youtube.com/embed/4bLFMdYjtCU?list=PL2vbAqrds2D2JSMZbUANuZHXHEM8rDLoN"
                        }
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title="Embedded youtube"
                      />
                    </div>
                  </div>

                  <div className="fs-5 pt-3 justifytext">
                    <div className="video-responsive">
                      <iframe
                        src={"https://www.youtube.com/embed/sWlR-QjYcsU"}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        title="Embedded youtube"
                      />
                    </div>
                  </div>

                  <div className="fs-5 pt-3 justifytext">
                    <div
                      style={{ display: "flex", justifyContent: "center" }}
                    ></div>
                  </div>
                </motion.div>
              </div>
            </div>

            {/* <!--end page right side Start --> */}
          </div>
        </div>
      </div>
    </div>

    <div className="row footer pt-4">
      <div className="container-xxl">
        <div className="container">
          <center>
            <h1>Footer Information</h1>
          </center>
        </div>
      </div>
    </div>
  </div>
);

export default Layout;
