import { useInView } from "react-intersection-observer";
import { motion, useAnimation } from "framer-motion";
import { useEffect } from "react";

function News() {
  const { ref, inView } = useInView();
  const animation = useAnimation();

  useEffect(() => {
    if (inView) {
      animation.start({
        x: 0,
        transition: {
          type: "spring",
          duration: 1,
          bounce: 0.3,
        },
      });
    }
    if (!inView) {
      animation.start({ x: "-100vw" });
    }

    console.log("Hook effect tutorial, InView =" + inView);
  }, [inView]);

  return (
    <div>
      <div className="mt-1">
        <div className="card  titlestrip ">
          <div className="card-header">
            <motion.div
              initial={{ x: 300, scale: 0.5 }}
              animate={{ x: 0, scale: 1 }}
              transition={{ duration: 2 }}
            >
              <h3>Latest News</h3>
            </motion.div>
          </div>

          <div className="justifytext fs-5 p-3"></div>
          <div ref={ref}>
            <motion.div className="justifytext fs-5 p-2" animate={animation}>
              <marquee direction="down"
  width="250"
  height="200"
  behavior="alternate" scrollamount="3"
  >
              
              <p>test one of the news of item 1</p>
              <p>test 2</p>
              <p>test news of item 3</p>


              <p>test one of the news of item 4</p>
              <p>test 5</p>
              <p>test news of item 6</p>
              </marquee>

            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default News;
