import Layout from "../components/Layout";
import contactjs from "../api/contactjs";
import { useEffect, useState } from "react";
import axios from 'axios'

export const getStaticProps = async () => {
  const res = await fetch("http://localhost:3006/contacts");
  const data = await res.json();
  console.log(data.id + "  ---" + data.name);
  return {
    props: {
      data,
    },
  };
};





const Contactlist = ({ data }) => {


  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const [infoMsg, setInfo] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()

    const data = {
      name,
      email,
      message
    }

    try {
      await axios.post('http://localhost:3006/contacts', data)
      console.log('Message sent successfully');
      setInfo('Message sent successfully')  ;
    } catch (err) {
      console.log(err)
    }
  }






  return (
    <>

<div>
<div className="row">

<h1>Contact form </h1>    
</div>



<div>
      <h1>Contact Us {infoMsg}</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="name">Name</label>
          <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label htmlFor="email">Email</label>
          <input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label htmlFor="message">Message</label>
          <textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>

</div>


      {data &&
        data.map((currElement) => {
          return (
            <h1>
              id {currElement.id} name-- {currElement.name} email id{" "}
              {currElement.email}{" "}
            </h1>
          );
        })}





    </>
  );
};

export default Contactlist;
