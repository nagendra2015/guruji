import Head from "next/head";
import { motion } from "framer-motion";

import CarouselList from "../components/CarouselList";
import Layout from "../components/Layout";
import { useEffect, useState } from 'react'

function Panchang() {
var x="10";    

const [mensen, setMensen] = useState([]);
const [location, setLocation] = useState();

const fetchApiData = async ({ latitude, longitude }) => {
    const res = await fetch(`https://openmensa.org/api/v2/canteens?near[lat]=${latitude}&near[lng]=${longitude}&near[dist]=50000`);
    const data = await res.json();
    setMensen(data);
};


useEffect(() => {
  if('geolocation' in navigator) {
      // Retrieve latitude & longitude coordinates from `navigator.geolocation` Web API
      navigator.geolocation.getCurrentPosition(({ coords }) => {
          const { latitude, longitude } = coords;
          setLocation({ latitude, longitude });
          console.log("lat and long is -"+latitude +" langitude "+longitude);
      })
  }
}, []);

useEffect(() => {
  // Fetch data from API if `location` object is set
  if (location) {
      fetchApiData(location);
  }
}, [location]);







  return (
    <Layout
      mainTitle="PANCHANG"
      footer={`Copyright ${new Date().getFullYear()}`}
    >
      <Head>
        <title>PANCHANG  latitude-  , longitude-   </title>
        <meta name="description" content="About page" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div>
        <CarouselList></CarouselList>
        <div className="mt-3">
          <div className="card  titlestrip ">
            <div className="card-header">
              <motion.div
                initial={{ x: 300, scale: 0.5 }}
                animate={{ x: 0, scale: 1 }}
                transition={{ duration: 2 }}
              >
                <h1>PANCHANG</h1>
              </motion.div>
            </div>
            <div className="justifytext fs-5 p-3">
              <p>
              Fill your desired date
              </p>
              <p>
              month year and get your Swara Calendar.
              </p>
              
            </div>

            <div className="justifytext fs-5 p-3 ">
              <p>
              This calculator compute Swara calendar. This is the most required information for Swara yoga Sadhana.
               We have different cycles within our body and mind connected with the movement of sun and moon . 
               These cycles hasÂ  very deepÂ Â  effect on our life. 
               BecauseÂ Â  ofÂ  ignorance about theses cycles we doÂ  different kind of mental, physical, material and spiritual work on wrong time that gives painful result in our life. To avoid and to expand in both material and spiritual life on fullest extent.Â  Swara yoga gives certain practices connected with different lunar days which can be practices under the guidance of a adept. Swara yoga is a secret tantric science it should be done correctly. Incorrect practice can bring imbalances in the energy system ,
               body and mind and can create pain and suffering
              </p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default Panchang;
